 import Header from "../components/headercomp"
import  MiddlePage from "../components/middlecomp"

const HomePage = () =>{
    return (
        <>
        <Header />
        <MiddlePage />
 </>
    )
}


export default HomePage